import numpy as np

def get_array(number_list):
    number_list_array = np.array(number_list)
    return number_list_array



Binning_refiner: Improving genome bins through the combination of different binning programs

Weizhi Song (songwz03@gmail.com)

The Centre for Marine Bio-Innovation (CMB), 
University of New South Wales, Sydney, Australia



